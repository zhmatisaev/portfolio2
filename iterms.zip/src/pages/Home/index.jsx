import React from 'react'
import { CustomCollapse } from '../../components/CustomCollapse'

export const Home = () => {
    return (
        <div>
            content llalal
            <CustomCollapse />
        </div>
    )
}