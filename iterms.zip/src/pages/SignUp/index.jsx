import React from 'react'

export const SignUp = () => {
    return (
        <div>
            sign up page
        </div>
    )
}