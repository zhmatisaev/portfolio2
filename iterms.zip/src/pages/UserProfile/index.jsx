import React from 'react'

export const UserProfile = () => {
    return (
        <div>
            User profile page
        </div>
    )
}