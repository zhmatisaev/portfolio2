import React from 'react'
import { Button, Select } from 'antd';
import './Header.less'
import { CustomButton } from '../CustomButton'

const { Option } = Select

export const Header = () => {
    return (
        <header className="container header">
            <div className="logo">iTerms</div>
            <nav>
                <a href="">Generate</a>
                <a href="">Contact us</a>
                <a href="">Pricing</a>
                <a href="">Blog</a>
            </nav>
            <Select defaultValue="EN" style={{ width: 69 }} >
                <Option value="EN">EN</Option>
                <Option value="RU">RU</Option>
            </Select>
            <div>
                <Button type="text">Log in</Button>
                <CustomButton primary>Sign up</CustomButton>
            </div>
        </header>
    )
}