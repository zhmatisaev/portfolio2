export const routes = {
  home: "/",
  login: "/login",
  sign_up: "/sign-up",
  user_profile: "/profile",
};
